"""Private teaching model. RayTracing ABCD optics + RayOptics spherical ray kernel."""
from __future__ import annotations

import math
import os
from pathlib import Path
import sys
import types

ROOT = Path(__file__).resolve().parent
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / "cache/matplotlib"))
os.environ.setdefault("MPLBACKEND", "Agg")
sys.path.insert(0, str(ROOT / "deps"))
# Import the documented numerical submodules without RayTracing's package-level
# version check / preferences writer. Vendor source remains unchanged.
package = types.ModuleType("raytracing")
package.__path__ = [str(ROOT / "deps/raytracing")]
sys.modules.setdefault("raytracing", package)

import numpy as np
from scipy.optimize import brentq
from scipy.special import j1
from scipy.signal import fftconvolve
from raytracing.matrix import Lens, Space, DielectricInterface
from raytracing.materials import N_BK7, N_BAF10, N_SF10
from rayoptics.elem.profiles import Spherical
from rayoptics.raytr.raytrace import bend
from rayoptics.raytr.traceerror import TraceError

TARGET_KEYS = ["targetA", "subject", "targetC"]
TARGET_LAYOUT = [(-.54, -.09, 1.8), (0, .165, 3), (.0525, .00375, .45)]
DEFAULTS = {"model": "ideal", "focal": 50, "fnumber": 2.8, "focus": 3, "sceneVersion": 2,
            "sensorW": 36, "sensorH": 24, "pitch": 6, "shiftX": 0, "shiftY": 0,
            "wavelength": 550, "thickness": .25, "bending": 0, "sensorOffset": 0,
            "cocMode": "traditional", "coc": 30, "blades": 0, "shutter": 1/125,
            "iso": 100, "exposureLock": True, "motion": 0, "diffraction": True,
            "rays": True, "rgb": False, "upright": True,"lightBrightness":300}
for letter,key,(x,y,z) in zip("ABC",TARGET_KEYS,TARGET_LAYOUT):
    DEFAULTS[key] = math.sqrt(x*x+y*y+z*z)
    DEFAULTS[f"target{letter}X"] = math.degrees(math.atan2(x,z))
    DEFAULTS[f"target{letter}Y"] = math.degrees(math.atan2(y,z))
BOUNDS = {"focal": (18, 135), "fnumber": (1.4, 22), "focus": (.3, 1000000), "subject": (.2, 200),
          "targetA": (.2, 200), "targetC": (.2, 200),
          "sensorW": (8, 44), "sensorH": (6, 33), "pitch": (1, 30), "shiftX": (-8, 8), "shiftY": (-8, 8),
          "wavelength": (420, 680), "thickness": (.12, .4), "bending": (-.7, .7),
          "sensorOffset": (-3, 3), "coc": (2, 100), "shutter": (1/4000, 1/15),
          "iso": (50, 6400), "motion": (0, 2),"lightBrightness":(.01,1000)}
BOUNDS.update({f"target{letter}{axis}":(-80,80) for letter in "ABC" for axis in "XY"})
GLASS = {"air": None, "N-BK7": N_BK7, "N-BAF10": N_BAF10, "N-SF10": N_SF10}


def clean(raw):
    p = dict(DEFAULTS)
    if not isinstance(raw, dict):
        raise ValueError("Settings must be an object")
    if raw.get("sceneVersion",2) != 2:
        raise ValueError("Unsupported scene coordinate version")
    for key, (lo, hi) in BOUNDS.items():
        if key == "focus" and raw.get(key) == "infinity":
            p[key] = "infinity"
            continue
        value = float(raw.get(key, p[key]))
        if not math.isfinite(value) or not lo <= value <= hi:
            raise ValueError(f"{key} must be between {lo} and {hi}")
        p[key] = value
    for key in ["exposureLock", "diffraction", "rays", "rgb", "upright"]:
        p[key] = bool(raw.get(key, p[key]))
    p["model"] = raw.get("model", p["model"])
    p["cocMode"] = raw.get("cocMode", p["cocMode"])
    p["blades"] = int(raw.get("blades", 0))
    if p["model"] not in {"ideal", "singlet", "doublet"} or p["cocMode"] not in {"traditional", "pixels", "custom"}:
        raise ValueError("Unknown optical model or blur criterion")
    if p["blades"] not in {0, 3, 4, 5, 6, 7, 8, 9}:
        raise ValueError("Unsupported aperture blade count")
    return p


def index(material, wavelength=550):
    return 1.0 if material == "air" else float(GLASS[material].n(wavelength / 1000))


def matrix_for(surfaces, wavelength=550):
    matrix = Space(0)
    last = 0.0
    before = "air"
    for surface in surfaces:
        matrix = Space(surface["z"] - last, n=index(before, wavelength)) * matrix
        matrix = DielectricInterface(index(before, wavelength), index(surface["after"], wavelength),
                                     R=surface["radius"], diameter=surface["diameter"]) * matrix
        before, last = surface["after"], surface["z"]
    return matrix


def prescription(p):
    f = p["focal"]
    if p["model"] == "ideal":
        return [], Lens(f), 0.0, .82 * f
    if p["model"] == "doublet":
        base = [{"z": 0, "radius": 33.3, "after": "N-BAF10", "diameter": 25.4},
                {"z": 9, "radius": -22.3, "after": "N-SF10", "diameter": 25.4},
                {"z": 11.5, "radius": -291.1, "after": "air", "diameter": 25.4}]
        baseline = -1 / matrix_for(base).C
        scale = f / baseline
        surfaces = [{**s, "z": s["z"] * scale, "radius": s["radius"] * scale,
                     "diameter": s["diameter"] * scale} for s in base]
    else:
        thickness, q = f * p["thickness"], p["bending"]
        n = index("N-BK7")
        # Positive, symmetric/asymmetric singlet; the large-radius solution.
        def power(radius):
            r1, r2 = radius / (1 + q), -radius / (1 - q)
            return (n - 1) * (1/r1 - 1/r2 + (n-1)*thickness/(n*r1*r2)) - 1/f
        radius = brentq(power, .45 * f, 4 * f)
        r1, r2 = radius / (1 + q), -radius / (1 - q)
        max_a = min(abs(r1), abs(r2)) * .95
        def sag(r, a):
            return r - math.copysign(math.sqrt(max(0, r*r-a*a)), r)
        def edge(a):
            return thickness + sag(r2, a) - sag(r1, a)
        if edge(max_a) < .02 * f:
            max_a = brentq(lambda a: edge(a)-.02*f, 0, max_a)
        diameter = min(.82 * f, 2 * max_a)
        surfaces = [{"z": 0, "radius": r1, "after": "N-BK7", "diameter": diameter},
                    {"z": thickness, "radius": r2, "after": "air", "diameter": diameter}]
    return surfaces, matrix_for(surfaces), surfaces[-1]["z"], surfaces[0]["diameter"]


def pupil_samples(count=61, blades=0):
    result = [(0.0, 0.0)]
    golden = math.pi * (3 - math.sqrt(5))
    for i in range(1, count):
        radius = math.sqrt((i-.5)/(count-1))
        angle = i * golden
        if blades:
            side = i % blades
            a, b = 2*math.pi*side/blades, 2*math.pi*(side+1)/blades
            v = (i * .6180339887498949) % 1
            result.append((radius*((1-v)*math.cos(a)+v*math.cos(b)), radius*((1-v)*math.sin(a)+v*math.sin(b))))
        else:
            result.append((radius * math.cos(angle), radius * math.sin(angle)))
    return result


def trace_one(p, surfaces, matrix, sensor_z, pupil, obj, wavelength=550):
    ax, ay = pupil
    hx, hy, distance = obj
    start = np.array([hx, hy, -distance], dtype=float)
    stop = np.array([ax, ay, 0.0])
    points = [start.tolist(), stop.tolist()]
    if not surfaces:
        tx, ty = (ax-hx)/distance-ax/p["focal"], (ay-hy)/distance-ay/p["focal"]
        hit = [ax+sensor_z*tx, ay+sensor_z*ty, sensor_z]
        return points + [hit], True
    direction = stop-start
    direction /= np.linalg.norm(direction)
    position = stop.copy()
    before = "air"
    try:
        for surface in surfaces:
            profile = Spherical(c=1/surface["radius"])
            local = position - np.array([0., 0., surface["z"]])
            _, hit = profile.intersect(local, direction, eps=1e-10, z_dir=1)
            position = hit + np.array([0., 0., surface["z"]])
            points.append(position.tolist())
            if math.hypot(hit[0], hit[1]) > surface["diameter"]/2 + 1e-8:
                return points, False
            direction = bend(direction, profile.normal(hit), index(before, wavelength), index(surface["after"], wavelength))
            before = surface["after"]
        if direction[2] <= 0:
            return points, False
        position = position + direction * ((sensor_z-position[2])/direction[2])
        points.append(position.tolist())
        return points, True
    except (TraceError, ValueError, FloatingPointError):
        return points, False


def point_spread(p, target, coefficient, working_n):
    """Incoherent geometric pupil/Airy approximation, not coherent defocus optics."""
    airy_mm = 2.44*(p["wavelength"]/1e6)*working_n
    radius = target["blur_um"]/2000
    n = 129
    extent = radius+max(4*airy_mm,4*p["pitch"]/1000)
    step = 2*extent/(n-1)
    axis = np.linspace(-extent,extent,n)
    xx,yy = np.meshgrid(axis,axis)
    geometric = np.zeros((n,n))
    if radius > step/4:
        for dx,dy in [(-.25,-.25),(-.25,.25),(.25,-.25),(.25,.25)]:
            x,y = xx+dx*step,yy+dy*step
            limit = radius
            if p["blades"]:
                angle = np.arctan2(y,x)+(math.pi if coefficient < 0 else 0)
                side = 2*math.pi/p["blades"]
                limit = radius*math.cos(side/2)/np.cos(angle % side-side/2)
            geometric += (np.hypot(x,y) <= limit)/4
    if not geometric.any():geometric[n//2,n//2] = 1
    geometric /= geometric.sum()
    kernel = geometric
    if p["diffraction"]:
        argument = np.pi*np.hypot(xx,yy)/((p["wavelength"]/1e6)*working_n)
        airy_kernel = np.ones_like(argument)
        nonzero = argument > 1e-10
        airy_kernel[nonzero] = (2*j1(argument[nonzero])/argument[nonzero])**2
        airy_kernel /= airy_kernel.sum()
        kernel = np.maximum(0,fftconvolve(geometric,airy_kernel,mode="same"))
    kernel /= kernel.sum()
    # A summed-area texture makes subpixel sources integrate over a whole sensor
    # or preview pixel instead of disappearing between individual raster samples.
    cdf = np.zeros((n+1,n+1))
    cdf[1:,1:] = np.cumsum(np.cumsum(kernel,axis=0),axis=1)
    cdf = np.clip(cdf,0,1)
    border = extent+step/2

    def integral(x,y):
        u = np.clip((x+border)/(2*border)*n,0,n)
        v = np.clip((y+border)/(2*border)*n,0,n)
        i,j = np.minimum(np.floor(u).astype(int),n-1),np.minimum(np.floor(v).astype(int),n-1)
        a,b = u-i,v-j
        return (cdf[j,i]*(1-a)*(1-b)+cdf[j,i+1]*a*(1-b)+cdf[j+1,i]*(1-a)*b+cdf[j+1,i+1]*a*b)

    pitch = p["pitch"]/1000
    u = (target["sensor_x"]-p["shiftX"]+p["sensorW"]/2)/pitch
    v = (p["sensorH"]/2+p["shiftY"]-target["sensor_y"])/pitch
    dx,dy = (.5-u % 1)*pitch,(v % 1-.5)*pitch
    x,y = np.meshgrid((np.arange(41)-20)*pitch+dx,-(np.arange(41)-20)*pitch+dy)
    half = pitch/2
    micro = np.maximum(0,integral(x+half,y+half)-integral(x-half,y+half)-integral(x+half,y-half)+integral(x-half,y-half))
    micro /= max(float(micro.max()),1e-30)
    return {"size":n+1,"extent_mm":border,"cdf":cdf.ravel().tolist(),
            "model":"Geometric pupil blur convolved with ideal circular Airy intensity; not a coherent wavefront PSF."},micro


def calculate(raw):
    p = clean(raw)
    surfaces, m, length, clear_diameter = prescription(p)
    f = -1 / m.C
    nominal_diameter = f/p["fnumber"]
    aperture = min(nominal_diameter, clear_diameter)
    # Inverse object distance gives the exact collimated-light limit at infinity.
    requested_inverse = 0 if p["focus"] == "infinity" else 1/(p["focus"]*1000)
    v = -(m.A+m.B*requested_inverse)/(m.C+m.D*requested_inverse) + p["sensorOffset"]
    if v <= 0:
        raise ValueError("No real image behind this lens at the selected focus")
    sensor_z = length + v
    complete = Space(v)*m
    a, b = float(complete.A), float(complete.B)
    if abs(a) < 1e-12:
        a = 0.0
    focus_state = "infinity" if a == 0 else "finite" if a < 0 else "virtual"
    effective_focus = -b/a if a < 0 else None
    criterion = p["coc"]/1000
    if p["cocMode"] == "traditional":
        criterion = math.hypot(p["sensorW"], p["sensorH"])/1500
    elif p["cocMode"] == "pixels":
        criterion = 2*p["pitch"]/1000
    threshold = criterion/aperture
    lo, hi = sorted([(-threshold-a)/b, (threshold-a)/b])
    near = 1/hi if hi > 0 else None
    far = 1/lo if lo > 0 else None
    working_n = abs(b)/aperture
    airy = 2.44 * (p["wavelength"]/1000) * working_n
    width_px, height_px = p["sensorW"]*1000/p["pitch"], p["sensorH"]*1000/p["pitch"]
    principal = m.principalPlanePositions(0)
    targets = []
    for i,(letter,key) in enumerate(zip("ABC",TARGET_KEYS)):
        # Field angles preserve x/z and y/z while radial range scales the whole
        # position vector about the entrance-pupil origin. Conjugates use z.
        sx,sy = [math.tan(math.radians(p[f"target{letter}{axis}"])) for axis in "XY"]
        radial = p[key]*1000
        distance = radial/math.sqrt(1+sx*sx+sy*sy)
        x,y = distance*sx,distance*sy
        targets.append({"id": i, "name": "Point source C" if i == 2 else f"Target {'ABC'[i]}", "distance": distance,
                        "radial_distance":radial,
                        "kind": "point" if i == 2 else "panel",
                        "x": x, "y": y, "blur_um": aperture*abs(a+b/distance)*1000,
                        "sensor_x": -b*x/distance, "sensor_y": -b*y/distance})
    all_rays, spots = [], []
    pupil = pupil_samples(49 if p["rgb"] else 73, p["blades"])
    wavelengths = [486.1, 550, 656.3] if p["rgb"] and surfaces else [p["wavelength"]]
    for wavelength in wavelengths:
        for i, target in enumerate(targets):
            for j, (px, py) in enumerate(pupil):
                points, transmitted = trace_one(p, surfaces, m, sensor_z, (px*aperture/2, py*aperture/2),
                                               (target["x"], target["y"], target["distance"]), wavelength)
                if j % 6 == 0:
                    all_rays.append({"points": points, "passed": transmitted, "target": i, "wavelength": wavelength})
                if transmitted and i == 1:
                    spots.append({"x": points[-1][0], "y": points[-1][1], "wavelength": wavelength})
    center = np.array([np.mean([s["x"] for s in spots]), np.mean([s["y"] for s in spots])]) if spots else np.zeros(2)
    spot_rms = float(np.sqrt(np.mean([(s["x"]-center[0])**2+(s["y"]-center[1])**2 for s in spots]))) if spots else None
    chromatic = []
    for wavelength in [486.1, 550, 656.3]:
        cm = matrix_for(surfaces, wavelength) if surfaces else m
        chromatic.append({"wavelength": wavelength, "efl": -1/cm.C,
                          "image_z": length-(cm.A+cm.B*requested_inverse)/(cm.C+cm.D*requested_inverse)})
    depths = [t["distance"] for t in targets]
    distances = np.geomspace(max(.15*min(depths), .001), 2*max(depths), 100)
    blur_curve = {"distance_m": (distances/1000).tolist(), "blur_um": (aperture*np.abs(a+b/distances)*1000).tolist()}
    psf_axis = np.linspace(-max(airy*2, p["pitch"]*8), max(airy*2, p["pitch"]*8), 241)
    argument = np.pi*np.abs(psf_axis)/(p["wavelength"]/1000*working_n)
    psf = np.ones_like(argument)
    nonzero = argument > 1e-10
    psf[nonzero] = (2*j1(argument[nonzero])/argument[nonzero])**2
    point,micro = point_spread(p,targets[2],a+b/targets[2]["distance"],working_n)
    warnings = []
    if nominal_diameter > clear_diameter:
        warnings.append("The lens clear diameter limits the requested aperture; effective f-number is shown.")
    if p["model"] != "ideal":
        warnings.append("3D rays and spot plots use real spherical refraction. The scene preview uses the equivalent first-order lens, not these aberrations.")
    if p["fnumber"] < 2.8:
        warnings.append("Fast-aperture diffraction and DOF figures are first-order estimates; they are not a calibrated lens prediction.")
    if focus_state == "virtual":
        warnings.append("This sensor offset has no finite positive object conjugate in the first-order model.")
    if any(abs(p[f"target{letter}{axis}"]) > 20 for letter in "ABC" for axis in "XY"):
        warnings.append("Large off-axis angles exceed the usual paraxial regime; the first-order scene and blur estimates are illustrative there.")
    return {"settings": p, "matrix": {k: float(getattr(m, k)) for k in ["A", "B", "C", "D"]},
            "projection": {"A": a, "K": b, "focus_inverse_m": 0.0 if a == 0 else -1000*a/b}, "surfaces": surfaces, "glass_length": length,
            "clear_diameter": clear_diameter, "aperture": aperture, "efl": f,
            "effective_fnumber": f/aperture, "working_fnumber": working_n, "sensor_z": sensor_z,
            "back_distance": v, "principal_planes": {"front": principal.z1, "back": principal.z2},
            "front_focal_z": principal.z1-f, "back_focal_z": principal.z2+f,
            "effective_focus_m": effective_focus/1000 if effective_focus else None,
            "focus_state": focus_state,
            "dof": {"near_m": near/1000 if near else None, "far_m": far/1000 if far else None,
                    "criterion_um": criterion*1000, "definition": "Geometric blur threshold, not a sharp/blurred boundary."},
            "sensor": {"width_px": round(width_px), "height_px": round(height_px), "megapixels": width_px*height_px/1e6,
                       "cx": width_px/2-p["shiftX"]*1000/p["pitch"],
                       "cy": height_px/2+p["shiftY"]*1000/p["pitch"],
                       "fx": b*1000/p["pitch"], "fy": b*1000/p["pitch"],
                       "nyquist_lp_mm": 1000/(2*p["pitch"])},
            "diffraction": {"airy_um": airy, "airy_pixels": airy/p["pitch"], "axis_um": psf_axis.tolist(),
                            "psf": psf.tolist(), "cutoff_lp_mm": 1000/(p["wavelength"]/1000*working_n),
                            "micro": micro.tolist()},
            "rays": all_rays, "spots": spots, "spot_rms_um": spot_rms*1000 if spot_rms is not None else None,
            "spot_center": center.tolist(), "targets": targets, "point_spread": point,"blur_curve": blur_curve, "chromatic": chromatic,
            "warnings": warnings, "relative_exposure": (2.8/working_n)**2*(p["shutter"]*125)*(p["iso"]/100),
            "versions": {"raytracing": "1.4.7", "rayoptics": "0.9.10"}}
